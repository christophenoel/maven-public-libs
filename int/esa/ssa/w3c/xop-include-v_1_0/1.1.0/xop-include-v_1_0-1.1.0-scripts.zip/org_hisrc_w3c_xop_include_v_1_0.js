var org_hisrc_w3c_xop_include_v_1_0_Module_Factory = function () {
  var org_hisrc_w3c_xop_include_v_1_0 = {
    n: 'org_hisrc_w3c_xop_include_v_1_0',
    dens: 'http:\/\/www.w3.org\/2003\/12\/xop\/include',
    tis: [{
        ln: 'Include',
        ps: [{
            n: 'href',
            an: {
              lp: 'href'
            },
            t: 'a'
          }]
      }],
    eis: [{
        en: 'Include',
        ti: '.Include'
      }]
  };
  return {
    org_hisrc_w3c_xop_include_v_1_0: org_hisrc_w3c_xop_include_v_1_0
  };
};
if (typeof define === 'function' && define.amd) {
  define([], org_hisrc_w3c_xop_include_v_1_0_Module_Factory);
}
else {
  var org_hisrc_w3c_xop_include_v_1_0_Module = org_hisrc_w3c_xop_include_v_1_0_Module_Factory();
  if (typeof module !== 'undefined' && module.exports) {
    module.exports.org_hisrc_w3c_xop_include_v_1_0 = org_hisrc_w3c_xop_include_v_1_0_Module.org_hisrc_w3c_xop_include_v_1_0;
  }
  else {
    var org_hisrc_w3c_xop_include_v_1_0 = org_hisrc_w3c_xop_include_v_1_0_Module.org_hisrc_w3c_xop_include_v_1_0;
  }
}