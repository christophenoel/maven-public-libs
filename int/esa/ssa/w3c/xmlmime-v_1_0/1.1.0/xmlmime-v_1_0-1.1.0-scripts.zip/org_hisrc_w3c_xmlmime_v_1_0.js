var org_hisrc_w3c_xmlmime_v_1_0_Module_Factory = function () {
  var org_hisrc_w3c_xmlmime_v_1_0 = {
    n: 'org_hisrc_w3c_xmlmime_v_1_0',
    dans: 'http:\/\/www.w3.org\/2004\/11\/xmlmime',
    tis: [{
        ln: 'Base64Binary',
        tn: {
          ns: 'http:\/\/www.w3.org\/2004\/11\/xmlmime',
          lp: 'base64Binary'
        },
        ps: [{
            n: 'value',
            ti: 'Base64Binary',
            t: 'v'
          }, {
            n: 'contentType',
            t: 'a'
          }]
      }, {
        ln: 'HexBinary',
        tn: {
          ns: 'http:\/\/www.w3.org\/2004\/11\/xmlmime',
          lp: 'hexBinary'
        },
        ps: [{
            n: 'value',
            t: 'v'
          }, {
            n: 'contentType',
            t: 'a'
          }]
      }],
    eis: []
  };
  return {
    org_hisrc_w3c_xmlmime_v_1_0: org_hisrc_w3c_xmlmime_v_1_0
  };
};
if (typeof define === 'function' && define.amd) {
  define([], org_hisrc_w3c_xmlmime_v_1_0_Module_Factory);
}
else {
  var org_hisrc_w3c_xmlmime_v_1_0_Module = org_hisrc_w3c_xmlmime_v_1_0_Module_Factory();
  if (typeof module !== 'undefined' && module.exports) {
    module.exports.org_hisrc_w3c_xmlmime_v_1_0 = org_hisrc_w3c_xmlmime_v_1_0_Module.org_hisrc_w3c_xmlmime_v_1_0;
  }
  else {
    var org_hisrc_w3c_xmlmime_v_1_0 = org_hisrc_w3c_xmlmime_v_1_0_Module.org_hisrc_w3c_xmlmime_v_1_0;
  }
}